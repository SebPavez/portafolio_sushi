<?php
// Heading
$_['heading_title'] = 'Googe Map';