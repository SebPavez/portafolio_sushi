<?php
// Text
$_['text_heading'] = 'Follow us';
$_['text_youtube'] = 'Youtube';
$_['text_facebook'] = 'Facebook';
$_['text_google_plus'] = 'Google Plus';
$_['text_twitter'] = 'Twitter';
$_['text_pinterest'] = 'Pinterest';
$_['text_instagram'] = 'Instagram';
$_['text_vimeo'] = 'Vimeo';