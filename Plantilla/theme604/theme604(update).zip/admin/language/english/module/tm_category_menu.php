<?php
// Heading
$_['heading_title']    = 'TM Category Menu';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified tm category module!';
$_['text_edit']        = 'Edit TM Category Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_name']     = 'Module Name';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify tm category module!';
$_['error_name']       = 'Module Name must be between 3 and 64 characters!';